# 🚀 Quick Reference Card

## Getting Started (30 Seconds!)

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Run the app
python app.py

# 3. Open browser
http://localhost:5000
```

## 🎯 Routes

| Route | Purpose | Auth Required |
|-------|---------|---------------|
| `/` | Redirect to dashboard or login | No |
| `/login` | User login page | No |
| `/register` | User registration | No |
| `/dashboard` | Main dashboard | ✅ Yes |
| `/trends` | Trend analysis | ✅ Yes |
| `/reports` | Sales reports | ✅ Yes |
| `/analytics` | Advanced analytics | ✅ Yes |
| `/settings` | User settings | ✅ Yes |
| `/logout` | Logout user | No |
| `/api/data` | Get forecast data | No |
| `/api/auth/login` | Login API | No |
| `/api/auth/register` | Register API | No |

## 👤 Demo Account

**Create your account on first run:**
1. Go to `/register`
2. Enter any name, email, password
3. Click "Create Account"
4. Login with those credentials

## 🎨 Pages Overview

### **Dashboard** 📊
- 4 metric cards (₹)
- Interactive forecast chart
- Period controls
- Quick actions

### **Trends** 📈
- Growth rates
- Pattern recognition
- Trend strength
- Predictions

### **Reports** 📄
- Monthly table
- Top performers
- Export options
- Summary stats

### **Analytics** 🔍
- Distribution charts
- Revenue breakdown
- AI insights
- Risk assessment
- Scenarios (3)

### **Settings** ⚙️
- Account info
- Notifications
- Forecast prefs
- Display options
- Security

## 💰 Currency

All values display in **₹ Indian Rupee**
- Charts show ₹
- Cards show ₹
- Tables show ₹
- Tooltips show ₹

## 🎨 Theme Colors

| Color | Usage |
|-------|-------|
| 🔵 Blue (#3b82f6) | Primary actions, links |
| 🟢 Green (#10b981) | Positive trends, success |
| 🔴 Red (#ef4444) | Negative trends, danger |
| 🟡 Yellow (#f59e0b) | Highlights, warnings |
| ⚫ Dark | Background, cards |

## 🔧 Key Functions

```python
# Backend (app.py)
- login_required decorator
- SalesForecaster class
- generate_historical_data()
- forecast_arima_style()
- calculate_metrics()

# Frontend (app.js)
- loadForecastData()
- updateMetrics()
- formatCurrency()
- renderChart()
- exportData()
```

## 📦 Dependencies

```text
Flask==3.0.0
numpy==1.26.2
pandas==2.1.4
Werkzeug==3.0.1
```

## 🐛 Troubleshooting

| Problem | Solution |
|---------|----------|
| Port 5000 in use | Change port in app.py line 194 |
| Module not found | `pip install -r requirements.txt` |
| Chart not showing | Check browser console (F12) |
| Session expires | That's normal, login again |
| Wrong currency | Already set to ₹ |

## 📱 Responsive Breakpoints

| Screen Size | Layout |
|-------------|--------|
| Desktop (>768px) | Full sidebar nav |
| Tablet (768px) | Stacked nav |
| Mobile (<768px) | Hamburger menu |

## 🎯 Quick Actions

**From Dashboard:**
- Click nav links to switch pages
- Use 30/60/90 day buttons for periods
- Hover charts for tooltips
- Click export for JSON data
- Click refresh for new forecast

**From Settings:**
- Toggle notifications on/off
- Change currency (₹ selected)
- Adjust forecast period
- Configure themes
- Contact support

## 🎊 Success Indicators

✅ Green arrow ↑ = Positive trend  
❌ Red arrow ↓ = Negative trend  
🟡 Yellow badge = Warning  
🔵 Blue highlight = Active/Selected  
✨ Smooth animations = Everything working  

---

**Need Help?** Check `README.md` or `UPDATE_SUMMARY.md`

**Ready!** Start with `python app.py` 🚀

