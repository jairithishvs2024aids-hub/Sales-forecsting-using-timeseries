from flask import Flask, render_template, jsonify, request, session, redirect, url_for
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import json
import warnings
import secrets
from functools import wraps
warnings.filterwarnings('ignore')

app = Flask(__name__)
app.secret_key = secrets.token_hex(32)

# In-memory user storage (for demo purposes)
users_db = {}

# Real company data for realistic dashboard
COMPANIES = [
    {'id': 1, 'name': 'Reliance Industries', 'sector': 'Conglomerate', 'revenue_base': 4500000},
    {'id': 2, 'name': 'Tata Consultancy Services', 'sector': 'IT Services', 'revenue_base': 3200000},
    {'id': 3, 'name': 'Infosys', 'sector': 'IT Services', 'revenue_base': 2800000},
    {'id': 4, 'name': 'HDFC Bank', 'sector': 'Banking', 'revenue_base': 3800000},
    {'id': 5, 'name': 'ICICI Bank', 'sector': 'Banking', 'revenue_base': 3500000},
    {'id': 6, 'name': 'Wipro', 'sector': 'IT Services', 'revenue_base': 2400000},
    {'id': 7, 'name': 'Hindustan Unilever', 'sector': 'FMCG', 'revenue_base': 2200000},
    {'id': 8, 'name': 'Bharti Airtel', 'sector': 'Telecommunications', 'revenue_base': 3100000},
    {'id': 9, 'name': 'Adani Enterprises', 'sector': 'Infrastructure', 'revenue_base': 2900000},
    {'id': 10, 'name': 'ITC Limited', 'sector': 'FMCG', 'revenue_base': 2600000},
]

# Decorator to require login
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

class SalesForecaster:
    """AI-powered sales forecasting using time series analysis"""
    
    def __init__(self):
        self.seed = 42
        np.random.seed(self.seed)
        
    def generate_historical_data(self, periods=120):
        """Generate realistic synthetic sales data with trends and seasonality"""
        dates = pd.date_range(end=datetime.now(), periods=periods, freq='D')
        
        # Create synthetic sales data with trend, seasonality, and noise
        trend = np.linspace(1000, 5000, periods)
        seasonal = 500 * np.sin(2 * np.pi * np.arange(periods) / 30)  # Monthly cycle
        noise = np.random.normal(0, 200, periods)
        sales = trend + seasonal + noise
        
        # Ensure non-negative sales
        sales = np.maximum(sales, 100)
        
        return dates, sales
    
    def forecast_arima_style(self, data, n_periods=30):
        """
        Simplified ARIMA-style forecasting
        Uses moving average and trend extrapolation
        """
        data = np.array(data)
        n = len(data)
        
        # Calculate moving averages
        ma7 = np.mean(data[-7:])  # 7-day moving average
        ma30 = np.mean(data[-30:])  # 30-day moving average
        
        # Calculate trend
        recent_trend = np.mean(np.diff(data[-30:]))
        
        # Seasonal component (assume monthly pattern)
        seasonal_pattern = []
        for i in range(30):
            day_of_month = i % 30
            seasonal_component = 200 * np.sin(2 * np.pi * day_of_month / 30)
            seasonal_pattern.append(seasonal_component)
        
        # Generate forecast
        forecast = []
        for i in range(n_periods):
            # Base prediction from moving average with trend
            base = ma7 + recent_trend * (i + 1)
            seasonal = seasonal_pattern[i % 30]
            forecast.append(base + seasonal + np.random.normal(0, 150))
        
        # Ensure non-negative
        forecast = np.maximum(forecast, 100)
        
        return forecast
    
    def calculate_metrics(self, historical, forecast):
        """Calculate forecasting metrics"""
        recent_avg = np.mean(historical[-7:])
        forecast_avg = np.mean(forecast)
        
        change = forecast_avg - recent_avg
        change_pct = (change / recent_avg * 100) if recent_avg > 0 else 0
        
        # Calculate confidence interval (simplified)
        std_dev = np.std(historical[-30:])
        upper_ci = forecast + 1.96 * std_dev
        lower_ci = forecast - 1.96 * std_dev
        
        return {
            'change': change,
            'change_pct': change_pct,
            'recent_avg': recent_avg,
            'forecast_avg': forecast_avg,
            'upper_ci': upper_ci.tolist(),
            'lower_ci': lower_ci.tolist()
        }

# Initialize forecaster
forecaster = SalesForecaster()

# Authentication routes
@app.route('/')
def index():
    """Redirect to login"""
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login')
def login():
    """Login page"""
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return render_template('login.html')

@app.route('/register')
def register():
    """Register page"""
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return render_template('register.html')

@app.route('/api/auth/login', methods=['POST'])
def api_login():
    """Login API"""
    data = request.json
    email = data.get('email', '').lower()
    password = data.get('password', '')
    
    if email in users_db and users_db[email]['password'] == password:
        session['user_id'] = email
        session['username'] = users_db[email]['name']
        return jsonify({'success': True, 'message': 'Login successful!'})
    else:
        return jsonify({'success': False, 'message': 'Invalid email or password'}), 401

@app.route('/api/auth/register', methods=['POST'])
def api_register():
    """Register API"""
    data = request.json
    name = data.get('name', '')
    email = data.get('email', '').lower()
    password = data.get('password', '')
    
    if email in users_db:
        return jsonify({'success': False, 'message': 'Email already registered'}), 400
    
    users_db[email] = {'name': name, 'email': email, 'password': password}
    return jsonify({'success': True, 'message': 'Registration successful!'})

@app.route('/logout')
def logout():
    """Logout"""
    session.clear()
    return redirect(url_for('login'))

# Dashboard routes
@app.route('/dashboard')
@login_required
def dashboard():
    """Main dashboard"""
    # Assign company based on user email hash for consistency
    user_id_hash = hash(session.get('user_id', '')) % len(COMPANIES)
    company = COMPANIES[user_id_hash]
    session['company_id'] = company['id']
    session['company_name'] = company['name']
    session['company_sector'] = company['sector']
    
    return render_template('dashboard.html', 
                         username=session.get('username'),
                         company_name=company['name'],
                         company_sector=company['sector'])

@app.route('/settings')
@login_required
def settings():
    """Settings page"""
    return render_template('settings.html', username=session.get('username'))

@app.route('/trends')
@login_required
def trends():
    """Trends analysis page"""
    company = COMPANIES[session.get('company_id', 0) - 1] if session.get('company_id') else COMPANIES[0]
    return render_template('trends.html', 
                         username=session.get('username'),
                         company_name=company['name'],
                         company_sector=company['sector'])

@app.route('/reports')
@login_required
def reports():
    """Reports page"""
    company = COMPANIES[session.get('company_id', 0) - 1] if session.get('company_id') else COMPANIES[0]
    return render_template('reports.html', 
                         username=session.get('username'),
                         company_name=company['name'],
                         company_sector=company['sector'])

@app.route('/analytics')
@login_required
def analytics():
    """Analytics page"""
    company = COMPANIES[session.get('company_id', 0) - 1] if session.get('company_id') else COMPANIES[0]
    return render_template('analytics.html', 
                         username=session.get('username'),
                         company_name=company['name'],
                         company_sector=company['sector'])

@app.route('/api/data')
def get_data():
    """Get historical and forecasted data"""
    try:
        # Generate historical data
        dates, sales = forecaster.generate_historical_data(120)
        
        # Generate forecast
        forecast = forecaster.forecast_arima_style(sales, 30)
        
        # Calculate metrics
        metrics = forecaster.calculate_metrics(sales, forecast)
        
        # Prepare dates for forecast
        forecast_dates = pd.date_range(start=dates[-1] + timedelta(days=1), periods=30, freq='D')
        
        # Format data for frontend
        historical_data = [{'date': date.strftime('%Y-%m-%d'), 'sales': float(val)} 
                          for date, val in zip(dates, sales)]
        
        forecast_data = [{'date': date.strftime('%Y-%m-%d'), 'sales': float(val)} 
                        for date, val in zip(forecast_dates, forecast)]
        
        upper_ci = [{'date': date.strftime('%Y-%m-%d'), 'sales': float(val)} 
                   for date, val in zip(forecast_dates, metrics['upper_ci'])]
        
        lower_ci = [{'date': date.strftime('%Y-%m-%d'), 'sales': float(val)} 
                   for date, val in zip(forecast_dates, metrics['lower_ci'])]
        
        return jsonify({
            'success': True,
            'historical': historical_data,
            'forecast': forecast_data,
            'upper_ci': upper_ci,
            'lower_ci': lower_ci,
            'metrics': {
                'change': round(metrics['change'], 2),
                'change_pct': round(metrics['change_pct'], 2),
                'recent_avg': round(metrics['recent_avg'], 2),
                'forecast_avg': round(metrics['forecast_avg'], 2)
            }
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/forecast', methods=['POST'])
def custom_forecast():
    """Generate custom forecast based on user parameters"""
    try:
        data = request.json
        periods = data.get('periods', 30)
        
        # Generate data
        dates, sales = forecaster.generate_historical_data(120)
        forecast = forecaster.forecast_arima_style(sales, periods)
        metrics = forecaster.calculate_metrics(sales, forecast)
        
        forecast_dates = pd.date_range(start=dates[-1] + timedelta(days=1), periods=periods, freq='D')
        
        forecast_data = [{'date': date.strftime('%Y-%m-%d'), 'sales': float(val)} 
                        for date, val in zip(forecast_dates, forecast)]
        
        return jsonify({
            'success': True,
            'forecast': forecast_data,
            'metrics': {
                'change': round(metrics['change'], 2),
                'change_pct': round(metrics['change_pct'], 2),
                'recent_avg': round(metrics['recent_avg'], 2),
                'forecast_avg': round(metrics['forecast_avg'], 2)
            }
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)

