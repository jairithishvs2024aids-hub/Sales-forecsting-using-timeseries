# Quick Start Guide 🚀

## Run the Dashboard in 3 Simple Steps

### Step 1: Install Dependencies
Open PowerShell or CMD in the project folder and run:
```bash
pip install -r requirements.txt
```

### Step 2: Run the Application
**Option A - Easy Way:**
Double-click `run.bat` file

**Option B - Manual:**
```bash
python app.py
```

### Step 3: Open in Browser
Navigate to: **http://localhost:5000**

That's it! Your AI Sales Forecasting Dashboard is now running! 🎉

---

## What You'll See

### 🎯 Dashboard Features:
- **4 Metric Cards** with animated values
- **Interactive Chart** showing historical + forecast
- **Trend Indicators** (green ↑ / red ↓)
- **Confidence Intervals** for predictions
- **Smooth Animations** throughout
- **Responsive Design** that works on all screens

### 🎨 Stock Market Theme:
- **Dark professional UI** with blue/green accents
- **Red/Green indicators** for positive/negative trends
- **Slick animations** and hover effects
- **Interactive buttons** and controls

### 📊 AI Forecasting:
- **120 days** of historical data
- **30-day forecast** with predictions
- **Moving average** calculations
- **Seasonal patterns** detection
- **95% confidence bands**

---

## Controls

| Button | Function |
|--------|----------|
| **30/60/90 Days** | Change forecast period |
| **🔄 Refresh Forecast** | Generate new predictions |
| **💾 Export Data** | Download forecast as JSON |
| **📋 View Details** | Scroll to information section |

---

## Troubleshooting

❌ **"Python not found"**
→ Install Python 3.8+ from python.org

❌ **"Module not found"**
→ Run: `pip install -r requirements.txt`

❌ **"Port 5000 in use"**
→ Change port in `app.py` line 140: `port=5001`

❌ **Chart not showing**
→ Check browser console (F12)

---

## Next Steps

- Customize colors in `static/css/style.css`
- Modify forecasting model in `app.py`
- Add real data sources
- Deploy to cloud (Heroku, AWS, etc.)

**Enjoy your AI Sales Forecasting Dashboard! 📈**

