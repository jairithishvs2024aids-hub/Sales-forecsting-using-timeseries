// Chart.js Configuration
let forecastChart = null;

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    // Only load dashboard-specific features if on dashboard
    if (document.getElementById('forecastChart')) {
        loadForecastData();
        setupEventListeners();
    }
});

// Setup event listeners
function setupEventListeners() {
    // Period control buttons
    document.querySelectorAll('.btn-control').forEach(btn => {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.btn-control').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            loadForecastData(parseInt(this.dataset.period));
        });
    });

    // Refresh button
    document.getElementById('refreshBtn').addEventListener('click', function() {
        this.innerHTML = '<span class="btn-icon">⏳</span><span>Refreshing...</span>';
        this.disabled = true;
        loadForecastData().finally(() => {
            this.innerHTML = '<span class="btn-icon">🔄</span><span>Refresh Forecast</span>';
            this.disabled = false;
        });
    });

    // Export button
    document.getElementById('exportBtn').addEventListener('click', function() {
        exportData();
    });

    // Details button
    document.getElementById('detailsBtn').addEventListener('click', function() {
        showDetails();
    });
}

// Load forecast data
async function loadForecastData(period = 30) {
    try {
        // Show loading state
        showLoading();

        // Fetch data from API
        const response = await fetch('/api/data');
        const data = await response.json();

        if (data.success) {
            updateMetrics(data.metrics);
            renderChart(data);
        } else {
            showError('Failed to load forecast data');
        }
    } catch (error) {
        console.error('Error loading data:', error);
        showError('Error connecting to server');
    }
}

// Update metrics cards
function updateMetrics(metrics) {
    // Recent Average
    const recentAvg = document.getElementById('recentAvg');
    recentAvg.textContent = formatCurrency(metrics.recent_avg);
    recentAvg.classList.remove('loading', 'positive', 'negative');

    // Forecast Average
    const forecastAvg = document.getElementById('forecastAvg');
    forecastAvg.textContent = formatCurrency(metrics.forecast_avg);
    forecastAvg.classList.remove('loading', 'positive', 'negative');

    // Expected Change
    const expectedChange = document.getElementById('expectedChange');
    const isPositive = metrics.change >= 0;
    expectedChange.textContent = formatCurrency(Math.abs(metrics.change));
    expectedChange.className = isPositive ? 'card-value positive' : 'card-value negative';
    expectedChange.classList.remove('loading');

    // Change Percentage
    const changePct = document.getElementById('changePct');
    const pctText = isPositive ? `+${metrics.change_pct}` : metrics.change_pct;
    changePct.textContent = `${pctText}%`;
    changePct.className = isPositive ? 'card-value positive' : 'card-value negative';
    changePct.classList.remove('loading');

    // Trend Indicator
    const trendIndicator = document.getElementById('trendIndicator');
    trendIndicator.className = isPositive ? 'trend-indicator positive' : 'trend-indicator negative';
    trendIndicator.innerHTML = isPositive 
        ? '<span class="arrow">↑</span>' 
        : '<span class="arrow">↓</span>';

    // Animate cards
    animateValueUpdate(expectedChange);
    animateValueUpdate(changePct);
}

// Format currency
function formatCurrency(value) {
    return '₹' + Math.round(value).toLocaleString('en-IN');
}

// Render chart
function renderChart(data) {
    const ctx = document.getElementById('forecastChart').getContext('2d');

    // Destroy existing chart if it exists
    if (forecastChart) {
        forecastChart.destroy();
    }

    // Prepare data
    const historicalLabels = data.historical.map(d => d.date);
    const historicalValues = data.historical.map(d => d.sales);
    const forecastLabels = data.forecast.map(d => d.date);
    const forecastValues = data.forecast.map(d => d.sales);
    const upperCI = data.upper_ci.map(d => d.sales);
    const lowerCI = data.lower_ci.map(d => d.sales);

    // Combine labels
    const allLabels = [...historicalLabels, ...forecastLabels];

    // Create dataset
    const historicalData = [...historicalValues, ...new Array(forecastValues.length).fill(null)];
    const forecastData = [...new Array(historicalValues.length).fill(null), ...forecastValues];
    const upperCIData = [...new Array(historicalValues.length).fill(null), ...upperCI];
    const lowerCIData = [...new Array(historicalValues.length).fill(null), ...lowerCI];

    // Chart configuration
    const config = {
        type: 'line',
        data: {
            labels: allLabels,
            datasets: [
                {
                    label: 'Historical Sales',
                    data: historicalData,
                    borderColor: '#3b82f6',
                    backgroundColor: 'rgba(59, 130, 246, 0.1)',
                    borderWidth: 2,
                    fill: false,
                    tension: 0.4,
                    pointRadius: 0,
                    pointHoverRadius: 5
                },
                {
                    label: 'Forecast',
                    data: forecastData,
                    borderColor: '#10b981',
                    backgroundColor: 'rgba(16, 185, 129, 0.1)',
                    borderWidth: 3,
                    borderDash: [5, 5],
                    fill: false,
                    tension: 0.4,
                    pointRadius: 3,
                    pointHoverRadius: 6
                },
                {
                    label: 'Upper Confidence',
                    data: upperCIData,
                    borderColor: 'rgba(245, 158, 11, 0.3)',
                    backgroundColor: 'rgba(245, 158, 11, 0.1)',
                    borderWidth: 1,
                    borderDash: [2, 2],
                    fill: '-1',
                    tension: 0.4,
                    pointRadius: 0
                },
                {
                    label: 'Lower Confidence',
                    data: lowerCIData,
                    borderColor: 'rgba(245, 158, 11, 0.3)',
                    backgroundColor: 'rgba(245, 158, 11, 0.1)',
                    borderWidth: 1,
                    borderDash: [2, 2],
                    fill: false,
                    tension: 0.4,
                    pointRadius: 0
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: {
                intersect: false,
                mode: 'index'
            },
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    backgroundColor: 'rgba(15, 22, 41, 0.95)',
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff',
                    borderColor: '#3b82f6',
                    borderWidth: 1,
                    padding: 12,
                    displayColors: true,
                    callbacks: {
                        label: function(context) {
                            let label = context.dataset.label || '';
                            if (label) {
                                label += ': ';
                            }
                            label += formatCurrency(context.parsed.y);
                            return label;
                        }
                    }
                }
            },
            scales: {
                x: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.05)',
                        borderColor: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#a0aec0',
                        maxRotation: 45,
                        minRotation: 45
                    }
                },
                y: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.05)',
                        borderColor: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#a0aec0',
                        callback: function(value) {
                            return '₹' + value.toLocaleString('en-IN');
                        }
                    }
                }
            },
            animation: {
                duration: 1500,
                easing: 'easeInOutQuart'
            }
        }
    };

    // Create chart
    forecastChart = new Chart(ctx, config);
}

// Show loading state
function showLoading() {
    document.querySelectorAll('.card-value').forEach(el => {
        if (el.textContent !== 'Loading...') {
            el.innerHTML = '<span class="loading">Loading...</span>';
        }
    });
}

// Show error message
function showError(message) {
    console.error(message);
    // You could add a toast notification here
}

// Animate value update
function animateValueUpdate(element) {
    element.style.transform = 'scale(1.2)';
    setTimeout(() => {
        element.style.transform = 'scale(1)';
    }, 300);
}

// Export data
function exportData() {
    fetch('/api/data')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const exportData = {
                    historical: data.historical,
                    forecast: data.forecast,
                    metrics: data.metrics,
                    exportDate: new Date().toISOString()
                };
                
                const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `sales_forecast_${new Date().getTime()}.json`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
                
                showNotification('Data exported successfully!');
            }
        })
        .catch(error => {
            console.error('Export error:', error);
            showNotification('Failed to export data', 'error');
        });
}

// Show details
function showDetails() {
    const cards = document.querySelectorAll('.details-card');
    cards[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
    
    // Add highlight effect
    cards.forEach(card => {
        card.style.animation = 'none';
        setTimeout(() => {
            card.style.animation = 'pulse 0.5s ease-in-out';
        }, 10);
    });
}

// Show notification
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${type === 'success' ? '#10b981' : '#ef4444'};
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 8px;
        box-shadow: 0 10px 40px rgba(0, 0, 0, 0.5);
        z-index: 1000;
        animation: slideInRight 0.3s ease-out;
    `;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s ease-in';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Add CSS animations for notification
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

