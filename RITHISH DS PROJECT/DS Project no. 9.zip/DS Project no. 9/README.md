# AI Sales Forecasting Dashboard 🚀

A sophisticated, stock market-inspired web application for AI-powered sales forecasting using time series analysis in Python with **authentication**, **multiple dashboard pages**, and **interactive insights**.

## Features

### 🔐 **Authentication System**
- Secure login and registration pages
- Session-based authentication
- Protected routes with decorators
- User management interface

### 📄 **Multi-Page Dashboard**
1. **Dashboard** - Main forecasting overview with interactive charts
2. **Trends** - Comprehensive trend analysis and patterns
3. **Reports** - Monthly reports and top performers
4. **Analytics** - Advanced AI insights and predictive scenarios
5. **Settings** - Account management and preferences

### 🎨 **Stock Market-Themed UI**
- Sleek dark theme with professional color scheme
- Red and green indicators for trends and changes
- Animated buttons and interactive elements
- Smooth transitions and hover effects
- Navigation bar with active page highlighting

### 📊 **Advanced Forecasting**
- AI-powered time series analysis
- Moving average (MA) components
- Trend extrapolation
- Seasonal pattern detection
- 95% confidence intervals

### 💹 **Interactive Charts**
- Real-time data visualization using Chart.js
- Historical vs forecasted data comparison
- Confidence interval bands
- Multiple chart types (line, bar, pie, doughnut)
- Interactive tooltips with ₹ currency formatting

### ⚡ **Dynamic Metrics**
- Current average (Last 7 days)
- Forecast average (Next 30 days)
- Expected change with trending indicators
- Percentage change display
- Indian Rupee (₹) currency throughout

### 🗺️ **Navigation**
- Top navigation bar on all pages
- User menu with logout
- Breadcrumb-style navigation
- Quick action links
- Responsive mobile menu

## Installation

### Prerequisites
- Python 3.8 or higher
- pip (Python package installer)

### Setup Steps

1. **Clone or navigate to the project directory**
```bash
cd "DS Project no. 9"
```

2. **Create a virtual environment (recommended)**
```bash
python -m venv venv
```

3. **Activate the virtual environment**
   - **Windows (PowerShell):**
   ```bash
   .\venv\Scripts\Activate.ps1
   ```
   - **Windows (CMD):**
   ```bash
   venv\Scripts\activate.bat
   ```
   - **Linux/Mac:**
   ```bash
   source venv/bin/activate
   ```

4. **Install dependencies**
```bash
pip install -r requirements.txt
```

## Running the Application

1. **Start the Flask server**
```bash
python app.py
```

2. **Open your browser**
Navigate to: `http://localhost:5000`

3. **Register/Login**
   - First time? Click "Register" to create an account
   - Enter your name, email, and password
   - Already registered? Just sign in

4. **Explore the Dashboard!**
   - Dashboard: View real-time forecasts and metrics
   - Trends: Analyze sales patterns and growth
   - Reports: Generate comprehensive sales reports
   - Analytics: Explore advanced AI insights
   - Settings: Configure preferences and notifications

## Project Structure

```
DS Project no. 9/
│
├── app.py                    # Flask backend with auth + forecasting
├── requirements.txt          # Python dependencies
├── README.md                 # This file
├── UPDATE_SUMMARY.md         # What's new in this version
│
├── templates/
│   ├── login.html           # Login page
│   ├── register.html        # Registration page
│   ├── dashboard.html       # Main dashboard
│   ├── trends.html          # Trends analysis
│   ├── reports.html         # Reports page
│   ├── analytics.html       # Analytics page
│   ├── settings.html        # Settings page
│   └── index.html           # Original (deprecated)
│
└── static/
    ├── css/
    │   ├── style.css        # Stock market-themed styles
    │   └── auth.css         # Authentication page styles
    └── js/
        └── app.js           # Interactive frontend logic
```

## Technical Details

### Backend (Python)
- **Flask**: Web framework with session management
- **NumPy**: Numerical computations
- **Pandas**: Data manipulation and time series
- **Secrets**: Secure secret key generation
- **Functools**: Login decorators
- **Mathematical Models**: Custom ARIMA-style forecasting

### Frontend
- **HTML5**: Modern markup with semantic structure
- **CSS3**: Advanced animations and responsive design
- **JavaScript**: Interactive charts and dynamic updates
- **Chart.js**: Beautiful, responsive charts
- **Session Management**: Client-side session handling

### Forecasting Algorithm
The system uses a simplified ARIMA-style approach:
1. **Data Generation**: Creates realistic synthetic sales data with trends and seasonality
2. **Moving Average**: Calculates 7-day and 30-day moving averages
3. **Trend Detection**: Analyzes recent trends in the data
4. **Seasonal Patterns**: Identifies and applies monthly cyclical patterns
5. **Confidence Intervals**: Calculates statistical prediction bands

## Usage

### Basic Features
- **View Dashboard**: See current and forecasted metrics at a glance
- **Interactive Chart**: Hover over data points for detailed information
- **Period Selection**: Switch between 30, 60, and 90-day forecasts
- **Refresh Data**: Get latest forecast updates

### Advanced Features
- **Export Data**: Download forecast data as JSON
- **Details View**: Scroll to detailed information sections
- **Animated Updates**: Smooth transitions when data refreshes

## Troubleshooting

### Common Issues

**Port already in use**
- Change the port in `app.py`: `app.run(debug=True, host='0.0.0.0', port=5001)`

**Module not found errors**
- Ensure virtual environment is activated
- Run `pip install -r requirements.txt` again

**Chart not displaying**
- Check browser console for errors
- Ensure Chart.js CDN is loading correctly

## Browser Compatibility

- ✅ Chrome/Edge (latest)
- ✅ Firefox (latest)
- ✅ Safari (latest)
- ⚠️ Internet Explorer (not supported)

## Performance

- Initial load time: < 2 seconds
- Data generation: < 1 second
- Chart rendering: < 1 second
- Smooth 60 FPS animations

## Future Enhancements

- [ ] Real database integration
- [ ] User authentication
- [ ] Multiple product forecasting
- [ ] Historical data upload
- [ ] Advanced ML models (Prophet, LSTM)
- [ ] Email alerts
- [ ] Mobile app

## Contributing

This project is designed as a standalone demonstration. Feel free to fork and customize for your needs!

## License

This project is open source and available for educational purposes.

## Support

For issues or questions:
1. Check the README for common solutions
2. Review the browser console for errors
3. Ensure all dependencies are installed correctly

## Acknowledgments

- Built with Flask and Python
- Chart.js for beautiful visualizations
- Stock market inspiration for the UI design

---

**Made with ❤️ using AI and Time Series Analysis**

💡 **Tip**: Keep the terminal running while using the dashboard. Press `Ctrl+C` to stop the server.

